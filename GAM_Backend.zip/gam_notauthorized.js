/*
               File: GAM_NotAuthorized
        Description: Not Authorized
             Author: GeneXus .NET Core Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:16:37.15
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_notauthorized', false, function () {
   this.ServerClass =  "gam_notauthorized" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e111h2_client=function()
   {
      /* 'Login' Routine */
      return this.executeServerEvent("'LOGIN'", true, null, false, false);
   };
   this.e131h2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e141h1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25];
   this.GXLastCtrlId =25;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"IMAGE1",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TBFORMTITLE", format:0,grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"TABLE2",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"TBLINKLOGIN", format:0,grid:0,evt:"e111h2_client"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"TBBACK", format:0,grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"TEXTBLOCK2", format:0,grid:0,evt:"e141h1_client"};
   this.Events = {"e111h2_client": ["'LOGIN'", true] ,"e131h2_client": ["ENTER", true] ,"e141h1_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["'LOGIN'"] = [[],[]];
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_notauthorized);});
