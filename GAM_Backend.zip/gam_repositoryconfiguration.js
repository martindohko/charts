/*
               File: GAM_RepositoryConfiguration
        Description: Repository configuration
             Author: GeneXus .NET Core Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:15:50.0
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_repositoryconfiguration', false, function () {
   this.ServerClass =  "gam_repositoryconfiguration" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV40SecurityAdministratorEmail=gx.fn.getControlValue("vSECURITYADMINISTRATOREMAIL") ;
      this.AV8CanRegisterUsers=gx.fn.getControlValue("vCANREGISTERUSERS") ;
      this.AV31pId=gx.fn.getIntegerValue("vPID",gx.thousandSeparator) ;
   };
   this.Validv_Logoutbehavior=function()
   {
      return this.validCliEvt("Validv_Logoutbehavior", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vLOGOUTBEHAVIOR");
         this.AnyError  = 0;
         if ( ! ( ( this.AV27LogoutBehavior == "clionl" ) || ( this.AV27LogoutBehavior == "cliip" ) || ( this.AV27LogoutBehavior == "all" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "SSO logout behavior"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Enabletracing=function()
   {
      return this.validCliEvt("Validv_Enabletracing", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vENABLETRACING");
         this.AnyError  = 0;
         if ( ! ( ( this.AV13EnableTracing == 0 ) || ( this.AV13EnableTracing == 1 ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Enable tracing"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Useridentification=function()
   {
      return this.validCliEvt("Validv_Useridentification", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERIDENTIFICATION");
         this.AnyError  = 0;
         if ( ! ( ( this.AV47UserIdentification == "name" ) || ( this.AV47UserIdentification == "email" ) || ( this.AV47UserIdentification == "namema" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User identification by"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Useractivationmethod=function()
   {
      return this.validCliEvt("Validv_Useractivationmethod", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERACTIVATIONMETHOD");
         this.AnyError  = 0;
         if ( ! ( ( this.AV44UserActivationMethod == "A" ) || ( this.AV44UserActivationMethod == "U" ) || ( this.AV44UserActivationMethod == "D" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User activation method"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Generatesessionstatistics=function()
   {
      return this.validCliEvt("Validv_Generatesessionstatistics", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vGENERATESESSIONSTATISTICS");
         this.AnyError  = 0;
         if ( ! ( ( this.AV19GenerateSessionStatistics == "None" ) || ( this.AV19GenerateSessionStatistics == "Minimum" ) || ( this.AV19GenerateSessionStatistics == "Detail" ) || ( this.AV19GenerateSessionStatistics == "Full" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Generate session statistics?"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Userremembermetype=function()
   {
      return this.validCliEvt("Validv_Userremembermetype", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vUSERREMEMBERMETYPE");
         this.AnyError  = 0;
         if ( ! ( ( this.AV50UserRememberMeType == "None" ) || ( this.AV50UserRememberMeType == "Login" ) || ( this.AV50UserRememberMeType == "Auth" ) || ( this.AV50UserRememberMeType == "Both" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "User remember me type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e120d2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e140d2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,12,13,16,17,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,86,87,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,131,132,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194];
   this.GXLastCtrlId =194;
   this.TAB1Container = gx.uc.getNew(this, 14, 0, "gx.ui.controls.Tab", "TAB1Container", "Tab1", "TAB1");
   var TAB1Container = this.TAB1Container;
   TAB1Container.setProp("Enabled", "Enabled", true, "boolean");
   TAB1Container.setProp("ActivePage", "Activepage", '', "int");
   TAB1Container.setProp("ActivePageControlName", "Activepagecontrolname", "", "char");
   TAB1Container.setProp("PageCount", "Pagecount", 3, "num");
   TAB1Container.setProp("Class", "Class", "Tab", "str");
   TAB1Container.setProp("HistoryManagement", "Historymanagement", false, "bool");
   TAB1Container.setProp("Visible", "Visible", true, "bool");
   TAB1Container.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(TAB1Container);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"GENERAL_TITLE", format:0,grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"TABPAGE1TABLE",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",gxz:"ZV22Id",gxold:"OV22Id",gxvar:"AV22Id",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV22Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV22Id=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vID",gx.O.AV22Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV22Id=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 24 , function() {
   });
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id:29 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",gxz:"ZV21GUID",gxold:"OV21GUID",gxvar:"AV21GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV21GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV21GUID,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV21GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id:34 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAMESPACE",gxz:"ZV30NameSpace",gxold:"OV30NameSpace",gxvar:"AV30NameSpace",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV30NameSpace=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV30NameSpace=Value},v2c:function(){gx.fn.setControlValue("vNAMESPACE",gx.O.AV30NameSpace,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV30NameSpace=this.val()},val:function(){return gx.fn.getControlValue("vNAMESPACE")},nac:gx.falseFn};
   this.declareDomainHdlr( 34 , function() {
   });
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id:39 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV29Name",gxold:"OV29Name",gxvar:"AV29Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV29Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 39 , function() {
   });
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id:44 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",gxz:"ZV12Dsc",gxold:"OV12Dsc",gxvar:"AV12Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV12Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 44 , function() {
   });
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"DEFAULTAUTHTYPENAMECELL",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id:49 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDEFAULTAUTHTYPENAME",gxz:"ZV9DefaultAuthTypeName",gxold:"OV9DefaultAuthTypeName",gxvar:"AV9DefaultAuthTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV9DefaultAuthTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV9DefaultAuthTypeName=Value},v2c:function(){gx.fn.setComboBoxValue("vDEFAULTAUTHTYPENAME",gx.O.AV9DefaultAuthTypeName);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV9DefaultAuthTypeName=this.val()},val:function(){return gx.fn.getControlValue("vDEFAULTAUTHTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 49 , function() {
   });
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id:54 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSESSIONEXPIRESONIPCHANGE",gxz:"ZV43SessionExpiresOnIPChange",gxold:"OV43SessionExpiresOnIPChange",gxvar:"AV43SessionExpiresOnIPChange",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV43SessionExpiresOnIPChange=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV43SessionExpiresOnIPChange=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vSESSIONEXPIRESONIPCHANGE",gx.O.AV43SessionExpiresOnIPChange,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV43SessionExpiresOnIPChange=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vSESSIONEXPIRESONIPCHANGE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 54 , function() {
   });
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id:59 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vALLOWOAUTHACCESS",gxz:"ZV5AllowOauthAccess",gxold:"OV5AllowOauthAccess",gxvar:"AV5AllowOauthAccess",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV5AllowOauthAccess=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AllowOauthAccess=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vALLOWOAUTHACCESS",gx.O.AV5AllowOauthAccess,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5AllowOauthAccess=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vALLOWOAUTHACCESS")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 59 , function() {
   });
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"DEFAULTSECURITYPOLICYIDCELL",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id:64 ,lvl:0,type:"int",len:9,dec:0,sign:false,pic:"ZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDEFAULTSECURITYPOLICYID",gxz:"ZV11DefaultSecurityPolicyId",gxold:"OV11DefaultSecurityPolicyId",gxvar:"AV11DefaultSecurityPolicyId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV11DefaultSecurityPolicyId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV11DefaultSecurityPolicyId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vDEFAULTSECURITYPOLICYID",gx.O.AV11DefaultSecurityPolicyId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11DefaultSecurityPolicyId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vDEFAULTSECURITYPOLICYID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 64 , function() {
   });
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"SSOBEHAVIORCELL",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"",grid:0};
   GXValidFnc[69]={ id:69 ,lvl:0,type:"char",len:6,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Logoutbehavior,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLOGOUTBEHAVIOR",gxz:"ZV27LogoutBehavior",gxold:"OV27LogoutBehavior",gxvar:"AV27LogoutBehavior",ucs:[],op:[69],ip:[69],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV27LogoutBehavior=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV27LogoutBehavior=Value},v2c:function(){gx.fn.setComboBoxValue("vLOGOUTBEHAVIOR",gx.O.AV27LogoutBehavior);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV27LogoutBehavior=this.val()},val:function(){return gx.fn.getControlValue("vLOGOUTBEHAVIOR")},nac:gx.falseFn};
   this.declareDomainHdlr( 69 , function() {
   });
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"DEFAULTROLEIDCELL",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id: 73, fld:"",grid:0};
   GXValidFnc[74]={ id:74 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDEFAULTROLEID",gxz:"ZV10DefaultRoleId",gxold:"OV10DefaultRoleId",gxvar:"AV10DefaultRoleId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV10DefaultRoleId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV10DefaultRoleId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vDEFAULTROLEID",gx.O.AV10DefaultRoleId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10DefaultRoleId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vDEFAULTROLEID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 74 , function() {
   });
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id:79 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:this.Validv_Enabletracing,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENABLETRACING",gxz:"ZV13EnableTracing",gxold:"OV13EnableTracing",gxvar:"AV13EnableTracing",ucs:[],op:[79],ip:[79],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV13EnableTracing=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV13EnableTracing=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vENABLETRACING",gx.O.AV13EnableTracing);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13EnableTracing=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vENABLETRACING",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 79 , function() {
   });
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id: 81, fld:"",grid:0};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id:84 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vENABLEWORKINGASGAMMANAGERREPO",gxz:"ZV52EnableWorkingAsGAMManagerRepo",gxold:"OV52EnableWorkingAsGAMManagerRepo",gxvar:"AV52EnableWorkingAsGAMManagerRepo",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV52EnableWorkingAsGAMManagerRepo=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV52EnableWorkingAsGAMManagerRepo=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vENABLEWORKINGASGAMMANAGERREPO",gx.O.AV52EnableWorkingAsGAMManagerRepo,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV52EnableWorkingAsGAMManagerRepo=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vENABLEWORKINGASGAMMANAGERREPO")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 84 , function() {
   });
   GXValidFnc[86]={ id: 86, fld:"USERS_TITLE", format:0,grid:0};
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"TABPAGE2TABLE",grid:0};
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id: 91, fld:"",grid:0};
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id:94 ,lvl:0,type:"char",len:6,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Useridentification,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERIDENTIFICATION",gxz:"ZV47UserIdentification",gxold:"OV47UserIdentification",gxvar:"AV47UserIdentification",ucs:[],op:[94],ip:[94],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV47UserIdentification=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV47UserIdentification=Value},v2c:function(){gx.fn.setComboBoxValue("vUSERIDENTIFICATION",gx.O.AV47UserIdentification);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV47UserIdentification=this.val()},val:function(){return gx.fn.getControlValue("vUSERIDENTIFICATION")},nac:gx.falseFn};
   this.declareDomainHdlr( 94 , function() {
   });
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"",grid:0};
   GXValidFnc[99]={ id:99 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Useractivationmethod,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERACTIVATIONMETHOD",gxz:"ZV44UserActivationMethod",gxold:"OV44UserActivationMethod",gxvar:"AV44UserActivationMethod",ucs:[],op:[99],ip:[99],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV44UserActivationMethod=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV44UserActivationMethod=Value},v2c:function(){gx.fn.setComboBoxValue("vUSERACTIVATIONMETHOD",gx.O.AV44UserActivationMethod);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV44UserActivationMethod=this.val()},val:function(){return gx.fn.getControlValue("vUSERACTIVATIONMETHOD")},nac:gx.falseFn};
   this.declareDomainHdlr( 99 , function() {
   });
   GXValidFnc[100]={ id: 100, fld:"",grid:0};
   GXValidFnc[101]={ id: 101, fld:"",grid:0};
   GXValidFnc[102]={ id: 102, fld:"",grid:0};
   GXValidFnc[103]={ id: 103, fld:"",grid:0};
   GXValidFnc[104]={ id:104 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERAUTOMATICACTIVATIONTIMEOUT",gxz:"ZV45UserAutomaticActivationTimeout",gxold:"OV45UserAutomaticActivationTimeout",gxvar:"AV45UserAutomaticActivationTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV45UserAutomaticActivationTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV45UserAutomaticActivationTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERAUTOMATICACTIVATIONTIMEOUT",gx.O.AV45UserAutomaticActivationTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV45UserAutomaticActivationTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERAUTOMATICACTIVATIONTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[105]={ id: 105, fld:"",grid:0};
   GXValidFnc[106]={ id: 106, fld:"",grid:0};
   GXValidFnc[107]={ id: 107, fld:"",grid:0};
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id:109 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSEREMAILISUNIQUE",gxz:"ZV46UserEmailisUnique",gxold:"OV46UserEmailisUnique",gxvar:"AV46UserEmailisUnique",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV46UserEmailisUnique=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV46UserEmailisUnique=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vUSEREMAILISUNIQUE",gx.O.AV46UserEmailisUnique,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV46UserEmailisUnique=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vUSEREMAILISUNIQUE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 109 , function() {
   });
   GXValidFnc[110]={ id: 110, fld:"",grid:0};
   GXValidFnc[111]={ id: 111, fld:"",grid:0};
   GXValidFnc[112]={ id: 112, fld:"",grid:0};
   GXValidFnc[113]={ id: 113, fld:"",grid:0};
   GXValidFnc[114]={ id:114 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDEMAIL",gxz:"ZV34RequiredEmail",gxold:"OV34RequiredEmail",gxvar:"AV34RequiredEmail",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV34RequiredEmail=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV34RequiredEmail=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDEMAIL",gx.O.AV34RequiredEmail,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV34RequiredEmail=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDEMAIL")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 114 , function() {
   });
   GXValidFnc[115]={ id: 115, fld:"",grid:0};
   GXValidFnc[116]={ id: 116, fld:"",grid:0};
   GXValidFnc[117]={ id: 117, fld:"",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id:119 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDPASSWORD",gxz:"ZV37RequiredPassword",gxold:"OV37RequiredPassword",gxvar:"AV37RequiredPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV37RequiredPassword=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV37RequiredPassword=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDPASSWORD",gx.O.AV37RequiredPassword,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV37RequiredPassword=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDPASSWORD")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 119 , function() {
   });
   GXValidFnc[120]={ id: 120, fld:"",grid:0};
   GXValidFnc[121]={ id: 121, fld:"",grid:0};
   GXValidFnc[122]={ id: 122, fld:"",grid:0};
   GXValidFnc[123]={ id: 123, fld:"",grid:0};
   GXValidFnc[124]={ id:124 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDFIRSTNAME",gxz:"ZV35RequiredFirstName",gxold:"OV35RequiredFirstName",gxvar:"AV35RequiredFirstName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV35RequiredFirstName=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV35RequiredFirstName=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDFIRSTNAME",gx.O.AV35RequiredFirstName,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV35RequiredFirstName=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDFIRSTNAME")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 124 , function() {
   });
   GXValidFnc[125]={ id: 125, fld:"",grid:0};
   GXValidFnc[126]={ id: 126, fld:"",grid:0};
   GXValidFnc[127]={ id: 127, fld:"",grid:0};
   GXValidFnc[128]={ id: 128, fld:"",grid:0};
   GXValidFnc[129]={ id:129 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREQUIREDLASTNAME",gxz:"ZV36RequiredLastName",gxold:"OV36RequiredLastName",gxvar:"AV36RequiredLastName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV36RequiredLastName=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV36RequiredLastName=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREQUIREDLASTNAME",gx.O.AV36RequiredLastName,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV36RequiredLastName=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREQUIREDLASTNAME")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 129 , function() {
   });
   GXValidFnc[131]={ id: 131, fld:"SESSION_TITLE", format:0,grid:0};
   GXValidFnc[132]={ id: 132, fld:"",grid:0};
   GXValidFnc[134]={ id: 134, fld:"TABPAGE3TABLE",grid:0};
   GXValidFnc[135]={ id: 135, fld:"",grid:0};
   GXValidFnc[136]={ id: 136, fld:"",grid:0};
   GXValidFnc[137]={ id: 137, fld:"",grid:0};
   GXValidFnc[138]={ id: 138, fld:"",grid:0};
   GXValidFnc[139]={ id:139 ,lvl:0,type:"char",len:20,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Generatesessionstatistics,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGENERATESESSIONSTATISTICS",gxz:"ZV19GenerateSessionStatistics",gxold:"OV19GenerateSessionStatistics",gxvar:"AV19GenerateSessionStatistics",ucs:[],op:[139],ip:[139],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV19GenerateSessionStatistics=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19GenerateSessionStatistics=Value},v2c:function(){gx.fn.setComboBoxValue("vGENERATESESSIONSTATISTICS",gx.O.AV19GenerateSessionStatistics);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV19GenerateSessionStatistics=this.val()},val:function(){return gx.fn.getControlValue("vGENERATESESSIONSTATISTICS")},nac:gx.falseFn};
   this.declareDomainHdlr( 139 , function() {
   });
   GXValidFnc[140]={ id: 140, fld:"",grid:0};
   GXValidFnc[141]={ id: 141, fld:"",grid:0};
   GXValidFnc[142]={ id: 142, fld:"",grid:0};
   GXValidFnc[143]={ id: 143, fld:"",grid:0};
   GXValidFnc[144]={ id:144 ,lvl:0,type:"int",len:6,dec:0,sign:false,pic:"ZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERSESSIONCACHETIMEOUT",gxz:"ZV51UserSessionCacheTimeout",gxold:"OV51UserSessionCacheTimeout",gxvar:"AV51UserSessionCacheTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV51UserSessionCacheTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV51UserSessionCacheTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERSESSIONCACHETIMEOUT",gx.O.AV51UserSessionCacheTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV51UserSessionCacheTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERSESSIONCACHETIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[145]={ id: 145, fld:"",grid:0};
   GXValidFnc[146]={ id: 146, fld:"",grid:0};
   GXValidFnc[147]={ id: 147, fld:"",grid:0};
   GXValidFnc[148]={ id: 148, fld:"",grid:0};
   GXValidFnc[149]={ id:149 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGIVEANONYMOUSSESSION",gxz:"ZV20GiveAnonymousSession",gxold:"OV20GiveAnonymousSession",gxvar:"AV20GiveAnonymousSession",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV20GiveAnonymousSession=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV20GiveAnonymousSession=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vGIVEANONYMOUSSESSION",gx.O.AV20GiveAnonymousSession,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20GiveAnonymousSession=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vGIVEANONYMOUSSESSION")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 149 , function() {
   });
   GXValidFnc[150]={ id: 150, fld:"",grid:0};
   GXValidFnc[151]={ id: 151, fld:"",grid:0};
   GXValidFnc[152]={ id: 152, fld:"",grid:0};
   GXValidFnc[153]={ id: 153, fld:"",grid:0};
   GXValidFnc[154]={ id:154 ,lvl:0,type:"int",len:2,dec:0,sign:false,pic:"Z9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLOGINATTEMPTSTOLOCKSESSION",gxz:"ZV25LoginAttemptsToLockSession",gxold:"OV25LoginAttemptsToLockSession",gxvar:"AV25LoginAttemptsToLockSession",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25LoginAttemptsToLockSession=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV25LoginAttemptsToLockSession=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vLOGINATTEMPTSTOLOCKSESSION",gx.O.AV25LoginAttemptsToLockSession,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV25LoginAttemptsToLockSession=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vLOGINATTEMPTSTOLOCKSESSION",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[155]={ id: 155, fld:"",grid:0};
   GXValidFnc[156]={ id: 156, fld:"",grid:0};
   GXValidFnc[157]={ id: 157, fld:"",grid:0};
   GXValidFnc[158]={ id: 158, fld:"",grid:0};
   GXValidFnc[159]={ id:159 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMUNBLOCKUSERTIMEOUT",gxz:"ZV18GAMUnblockUserTimeout",gxold:"OV18GAMUnblockUserTimeout",gxvar:"AV18GAMUnblockUserTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18GAMUnblockUserTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV18GAMUnblockUserTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vGAMUNBLOCKUSERTIMEOUT",gx.O.AV18GAMUnblockUserTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV18GAMUnblockUserTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vGAMUNBLOCKUSERTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[160]={ id: 160, fld:"",grid:0};
   GXValidFnc[161]={ id: 161, fld:"",grid:0};
   GXValidFnc[162]={ id: 162, fld:"",grid:0};
   GXValidFnc[163]={ id: 163, fld:"",grid:0};
   GXValidFnc[164]={ id:164 ,lvl:0,type:"int",len:2,dec:0,sign:false,pic:"Z9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vLOGINATTEMPTSTOLOCKUSER",gxz:"ZV26LoginAttemptsToLockUser",gxold:"OV26LoginAttemptsToLockUser",gxvar:"AV26LoginAttemptsToLockUser",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV26LoginAttemptsToLockUser=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV26LoginAttemptsToLockUser=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vLOGINATTEMPTSTOLOCKUSER",gx.O.AV26LoginAttemptsToLockUser,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV26LoginAttemptsToLockUser=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vLOGINATTEMPTSTOLOCKUSER",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[165]={ id: 165, fld:"",grid:0};
   GXValidFnc[166]={ id: 166, fld:"",grid:0};
   GXValidFnc[167]={ id: 167, fld:"",grid:0};
   GXValidFnc[168]={ id: 168, fld:"",grid:0};
   GXValidFnc[169]={ id:169 ,lvl:0,type:"int",len:2,dec:0,sign:false,pic:"Z9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vMINIMUMAMOUNTCHARACTERSINLOGIN",gxz:"ZV28MinimumAmountCharactersInLogin",gxold:"OV28MinimumAmountCharactersInLogin",gxvar:"AV28MinimumAmountCharactersInLogin",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV28MinimumAmountCharactersInLogin=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV28MinimumAmountCharactersInLogin=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vMINIMUMAMOUNTCHARACTERSINLOGIN",gx.O.AV28MinimumAmountCharactersInLogin,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV28MinimumAmountCharactersInLogin=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vMINIMUMAMOUNTCHARACTERSINLOGIN",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[170]={ id: 170, fld:"",grid:0};
   GXValidFnc[171]={ id: 171, fld:"",grid:0};
   GXValidFnc[172]={ id: 172, fld:"",grid:0};
   GXValidFnc[173]={ id: 173, fld:"",grid:0};
   GXValidFnc[174]={ id:174 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERRECOVERYPASSWORDKEYTIMEOUT",gxz:"ZV48UserRecoveryPasswordKeyTimeOut",gxold:"OV48UserRecoveryPasswordKeyTimeOut",gxvar:"AV48UserRecoveryPasswordKeyTimeOut",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV48UserRecoveryPasswordKeyTimeOut=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV48UserRecoveryPasswordKeyTimeOut=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERRECOVERYPASSWORDKEYTIMEOUT",gx.O.AV48UserRecoveryPasswordKeyTimeOut,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV48UserRecoveryPasswordKeyTimeOut=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERRECOVERYPASSWORDKEYTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[175]={ id: 175, fld:"",grid:0};
   GXValidFnc[176]={ id: 176, fld:"",grid:0};
   GXValidFnc[177]={ id: 177, fld:"",grid:0};
   GXValidFnc[178]={ id: 178, fld:"",grid:0};
   GXValidFnc[179]={ id:179 ,lvl:0,type:"int",len:4,dec:0,sign:false,pic:"ZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERREMEMBERMETIMEOUT",gxz:"ZV49UserRememberMeTimeOut",gxold:"OV49UserRememberMeTimeOut",gxvar:"AV49UserRememberMeTimeOut",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV49UserRememberMeTimeOut=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV49UserRememberMeTimeOut=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vUSERREMEMBERMETIMEOUT",gx.O.AV49UserRememberMeTimeOut,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV49UserRememberMeTimeOut=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vUSERREMEMBERMETIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[180]={ id: 180, fld:"",grid:0};
   GXValidFnc[181]={ id: 181, fld:"",grid:0};
   GXValidFnc[182]={ id: 182, fld:"",grid:0};
   GXValidFnc[183]={ id: 183, fld:"",grid:0};
   GXValidFnc[184]={ id:184 ,lvl:0,type:"char",len:6,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Userremembermetype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERREMEMBERMETYPE",gxz:"ZV50UserRememberMeType",gxold:"OV50UserRememberMeType",gxvar:"AV50UserRememberMeType",ucs:[],op:[184],ip:[184],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV50UserRememberMeType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV50UserRememberMeType=Value},v2c:function(){gx.fn.setComboBoxValue("vUSERREMEMBERMETYPE",gx.O.AV50UserRememberMeType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV50UserRememberMeType=this.val()},val:function(){return gx.fn.getControlValue("vUSERREMEMBERMETYPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 184 , function() {
   });
   GXValidFnc[185]={ id: 185, fld:"",grid:0};
   GXValidFnc[186]={ id: 186, fld:"",grid:0};
   GXValidFnc[187]={ id: 187, fld:"",grid:0};
   GXValidFnc[188]={ id: 188, fld:"",grid:0};
   GXValidFnc[189]={ id:189 ,lvl:0,type:"int",len:6,dec:0,sign:false,pic:"ZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREPOSITORYCACHETIMEOUT",gxz:"ZV33RepositoryCacheTimeout",gxold:"OV33RepositoryCacheTimeout",gxvar:"AV33RepositoryCacheTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV33RepositoryCacheTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV33RepositoryCacheTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vREPOSITORYCACHETIMEOUT",gx.O.AV33RepositoryCacheTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV33RepositoryCacheTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vREPOSITORYCACHETIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[190]={ id: 190, fld:"",grid:0};
   GXValidFnc[191]={ id: 191, fld:"",grid:0};
   GXValidFnc[192]={ id: 192, fld:"",grid:0};
   GXValidFnc[193]={ id: 193, fld:"",grid:0};
   GXValidFnc[194]={ id: 194, fld:"CONFIRM",grid:0,evt:"e120d2_client",std:"ENTER"};
   this.AV22Id = 0 ;
   this.ZV22Id = 0 ;
   this.OV22Id = 0 ;
   this.AV21GUID = "" ;
   this.ZV21GUID = "" ;
   this.OV21GUID = "" ;
   this.AV30NameSpace = "" ;
   this.ZV30NameSpace = "" ;
   this.OV30NameSpace = "" ;
   this.AV29Name = "" ;
   this.ZV29Name = "" ;
   this.OV29Name = "" ;
   this.AV12Dsc = "" ;
   this.ZV12Dsc = "" ;
   this.OV12Dsc = "" ;
   this.AV9DefaultAuthTypeName = "" ;
   this.ZV9DefaultAuthTypeName = "" ;
   this.OV9DefaultAuthTypeName = "" ;
   this.AV43SessionExpiresOnIPChange = false ;
   this.ZV43SessionExpiresOnIPChange = false ;
   this.OV43SessionExpiresOnIPChange = false ;
   this.AV5AllowOauthAccess = false ;
   this.ZV5AllowOauthAccess = false ;
   this.OV5AllowOauthAccess = false ;
   this.AV11DefaultSecurityPolicyId = 0 ;
   this.ZV11DefaultSecurityPolicyId = 0 ;
   this.OV11DefaultSecurityPolicyId = 0 ;
   this.AV27LogoutBehavior = "" ;
   this.ZV27LogoutBehavior = "" ;
   this.OV27LogoutBehavior = "" ;
   this.AV10DefaultRoleId = 0 ;
   this.ZV10DefaultRoleId = 0 ;
   this.OV10DefaultRoleId = 0 ;
   this.AV13EnableTracing = 0 ;
   this.ZV13EnableTracing = 0 ;
   this.OV13EnableTracing = 0 ;
   this.AV52EnableWorkingAsGAMManagerRepo = false ;
   this.ZV52EnableWorkingAsGAMManagerRepo = false ;
   this.OV52EnableWorkingAsGAMManagerRepo = false ;
   this.AV47UserIdentification = "" ;
   this.ZV47UserIdentification = "" ;
   this.OV47UserIdentification = "" ;
   this.AV44UserActivationMethod = "" ;
   this.ZV44UserActivationMethod = "" ;
   this.OV44UserActivationMethod = "" ;
   this.AV45UserAutomaticActivationTimeout = 0 ;
   this.ZV45UserAutomaticActivationTimeout = 0 ;
   this.OV45UserAutomaticActivationTimeout = 0 ;
   this.AV46UserEmailisUnique = false ;
   this.ZV46UserEmailisUnique = false ;
   this.OV46UserEmailisUnique = false ;
   this.AV34RequiredEmail = false ;
   this.ZV34RequiredEmail = false ;
   this.OV34RequiredEmail = false ;
   this.AV37RequiredPassword = false ;
   this.ZV37RequiredPassword = false ;
   this.OV37RequiredPassword = false ;
   this.AV35RequiredFirstName = false ;
   this.ZV35RequiredFirstName = false ;
   this.OV35RequiredFirstName = false ;
   this.AV36RequiredLastName = false ;
   this.ZV36RequiredLastName = false ;
   this.OV36RequiredLastName = false ;
   this.AV19GenerateSessionStatistics = "" ;
   this.ZV19GenerateSessionStatistics = "" ;
   this.OV19GenerateSessionStatistics = "" ;
   this.AV51UserSessionCacheTimeout = 0 ;
   this.ZV51UserSessionCacheTimeout = 0 ;
   this.OV51UserSessionCacheTimeout = 0 ;
   this.AV20GiveAnonymousSession = false ;
   this.ZV20GiveAnonymousSession = false ;
   this.OV20GiveAnonymousSession = false ;
   this.AV25LoginAttemptsToLockSession = 0 ;
   this.ZV25LoginAttemptsToLockSession = 0 ;
   this.OV25LoginAttemptsToLockSession = 0 ;
   this.AV18GAMUnblockUserTimeout = 0 ;
   this.ZV18GAMUnblockUserTimeout = 0 ;
   this.OV18GAMUnblockUserTimeout = 0 ;
   this.AV26LoginAttemptsToLockUser = 0 ;
   this.ZV26LoginAttemptsToLockUser = 0 ;
   this.OV26LoginAttemptsToLockUser = 0 ;
   this.AV28MinimumAmountCharactersInLogin = 0 ;
   this.ZV28MinimumAmountCharactersInLogin = 0 ;
   this.OV28MinimumAmountCharactersInLogin = 0 ;
   this.AV48UserRecoveryPasswordKeyTimeOut = 0 ;
   this.ZV48UserRecoveryPasswordKeyTimeOut = 0 ;
   this.OV48UserRecoveryPasswordKeyTimeOut = 0 ;
   this.AV49UserRememberMeTimeOut = 0 ;
   this.ZV49UserRememberMeTimeOut = 0 ;
   this.OV49UserRememberMeTimeOut = 0 ;
   this.AV50UserRememberMeType = "" ;
   this.ZV50UserRememberMeType = "" ;
   this.OV50UserRememberMeType = "" ;
   this.AV33RepositoryCacheTimeout = 0 ;
   this.ZV33RepositoryCacheTimeout = 0 ;
   this.OV33RepositoryCacheTimeout = 0 ;
   this.AV22Id = 0 ;
   this.AV21GUID = "" ;
   this.AV30NameSpace = "" ;
   this.AV29Name = "" ;
   this.AV12Dsc = "" ;
   this.AV9DefaultAuthTypeName = "" ;
   this.AV43SessionExpiresOnIPChange = false ;
   this.AV5AllowOauthAccess = false ;
   this.AV11DefaultSecurityPolicyId = 0 ;
   this.AV27LogoutBehavior = "" ;
   this.AV10DefaultRoleId = 0 ;
   this.AV13EnableTracing = 0 ;
   this.AV52EnableWorkingAsGAMManagerRepo = false ;
   this.AV47UserIdentification = "" ;
   this.AV44UserActivationMethod = "" ;
   this.AV45UserAutomaticActivationTimeout = 0 ;
   this.AV46UserEmailisUnique = false ;
   this.AV34RequiredEmail = false ;
   this.AV37RequiredPassword = false ;
   this.AV35RequiredFirstName = false ;
   this.AV36RequiredLastName = false ;
   this.AV19GenerateSessionStatistics = "" ;
   this.AV51UserSessionCacheTimeout = 0 ;
   this.AV20GiveAnonymousSession = false ;
   this.AV25LoginAttemptsToLockSession = 0 ;
   this.AV18GAMUnblockUserTimeout = 0 ;
   this.AV26LoginAttemptsToLockUser = 0 ;
   this.AV28MinimumAmountCharactersInLogin = 0 ;
   this.AV48UserRecoveryPasswordKeyTimeOut = 0 ;
   this.AV49UserRememberMeTimeOut = 0 ;
   this.AV50UserRememberMeType = "" ;
   this.AV33RepositoryCacheTimeout = 0 ;
   this.AV31pId = 0 ;
   this.AV40SecurityAdministratorEmail = "" ;
   this.AV8CanRegisterUsers = false ;
   this.Events = {"e120d2_client": ["ENTER", true] ,"e140d2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV40SecurityAdministratorEmail',fld:'vSECURITYADMINISTRATOREMAIL',pic:'',hsh:true},{av:'AV8CanRegisterUsers',fld:'vCANREGISTERUSERS',pic:'',hsh:true},{av:'AV31pId',fld:'vPID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV22Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EvtParms["START"] = [[{av:'AV24Language',fld:'vLANGUAGE',pic:''},{ctrl:'vDEFAULTAUTHTYPENAME'},{av:'AV9DefaultAuthTypeName',fld:'vDEFAULTAUTHTYPENAME',pic:''},{ctrl:'vDEFAULTSECURITYPOLICYID'},{av:'AV11DefaultSecurityPolicyId',fld:'vDEFAULTSECURITYPOLICYID',pic:'ZZZZZZZZ9'},{ctrl:'vDEFAULTROLEID'},{av:'AV10DefaultRoleId',fld:'vDEFAULTROLEID',pic:'ZZZZZZZZZZZ9'},{av:'AV31pId',fld:'vPID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'gx.fn.getCtrlProperty("DEFAULTAUTHTYPENAMECELL","Visible")',ctrl:'DEFAULTAUTHTYPENAMECELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("DEFAULTSECURITYPOLICYIDCELL","Visible")',ctrl:'DEFAULTSECURITYPOLICYIDCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("DEFAULTROLEIDCELL","Visible")',ctrl:'DEFAULTROLEIDCELL',prop:'Visible'},{ctrl:'vDEFAULTAUTHTYPENAME'},{av:'AV9DefaultAuthTypeName',fld:'vDEFAULTAUTHTYPENAME',pic:''},{ctrl:'vDEFAULTSECURITYPOLICYID'},{av:'AV11DefaultSecurityPolicyId',fld:'vDEFAULTSECURITYPOLICYID',pic:'ZZZZZZZZ9'},{ctrl:'vDEFAULTROLEID'},{av:'AV10DefaultRoleId',fld:'vDEFAULTROLEID',pic:'ZZZZZZZZZZZ9'},{av:'AV22Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV21GUID',fld:'vGUID',pic:''},{av:'AV30NameSpace',fld:'vNAMESPACE',pic:''},{av:'AV29Name',fld:'vNAME',pic:''},{av:'AV12Dsc',fld:'vDSC',pic:''},{ctrl:'vUSERIDENTIFICATION'},{av:'AV47UserIdentification',fld:'vUSERIDENTIFICATION',pic:''},{ctrl:'vGENERATESESSIONSTATISTICS'},{av:'AV19GenerateSessionStatistics',fld:'vGENERATESESSIONSTATISTICS',pic:''},{ctrl:'vUSERACTIVATIONMETHOD'},{av:'AV44UserActivationMethod',fld:'vUSERACTIVATIONMETHOD',pic:''},{av:'AV45UserAutomaticActivationTimeout',fld:'vUSERAUTOMATICACTIVATIONTIMEOUT',pic:'ZZZ9'},{ctrl:'vUSERREMEMBERMETYPE'},{av:'AV50UserRememberMeType',fld:'vUSERREMEMBERMETYPE',pic:''},{av:'AV49UserRememberMeTimeOut',fld:'vUSERREMEMBERMETIMEOUT',pic:'ZZZ9'},{av:'AV48UserRecoveryPasswordKeyTimeOut',fld:'vUSERRECOVERYPASSWORDKEYTIMEOUT',pic:'ZZZ9'},{av:'AV28MinimumAmountCharactersInLogin',fld:'vMINIMUMAMOUNTCHARACTERSINLOGIN',pic:'Z9'},{av:'AV26LoginAttemptsToLockUser',fld:'vLOGINATTEMPTSTOLOCKUSER',pic:'Z9'},{av:'AV18GAMUnblockUserTimeout',fld:'vGAMUNBLOCKUSERTIMEOUT',pic:'ZZZ9'},{av:'AV25LoginAttemptsToLockSession',fld:'vLOGINATTEMPTSTOLOCKSESSION',pic:'Z9'},{av:'AV51UserSessionCacheTimeout',fld:'vUSERSESSIONCACHETIMEOUT',pic:'ZZZZZ9'},{av:'AV33RepositoryCacheTimeout',fld:'vREPOSITORYCACHETIMEOUT',pic:'ZZZZZ9'},{ctrl:'vLOGOUTBEHAVIOR'},{av:'AV27LogoutBehavior',fld:'vLOGOUTBEHAVIOR',pic:''},{av:'AV40SecurityAdministratorEmail',fld:'vSECURITYADMINISTRATOREMAIL',pic:'',hsh:true},{av:'AV8CanRegisterUsers',fld:'vCANREGISTERUSERS',pic:'',hsh:true},{ctrl:'vENABLETRACING'},{av:'AV13EnableTracing',fld:'vENABLETRACING',pic:'ZZZ9'},{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EvtParms["ENTER"] = [[{av:'AV22Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV29Name',fld:'vNAME',pic:''},{av:'AV12Dsc',fld:'vDSC',pic:''},{ctrl:'vDEFAULTAUTHTYPENAME'},{av:'AV9DefaultAuthTypeName',fld:'vDEFAULTAUTHTYPENAME',pic:''},{ctrl:'vUSERIDENTIFICATION'},{av:'AV47UserIdentification',fld:'vUSERIDENTIFICATION',pic:''},{ctrl:'vGENERATESESSIONSTATISTICS'},{av:'AV19GenerateSessionStatistics',fld:'vGENERATESESSIONSTATISTICS',pic:''},{ctrl:'vUSERACTIVATIONMETHOD'},{av:'AV44UserActivationMethod',fld:'vUSERACTIVATIONMETHOD',pic:''},{av:'AV45UserAutomaticActivationTimeout',fld:'vUSERAUTOMATICACTIVATIONTIMEOUT',pic:'ZZZ9'},{av:'AV18GAMUnblockUserTimeout',fld:'vGAMUNBLOCKUSERTIMEOUT',pic:'ZZZ9'},{ctrl:'vUSERREMEMBERMETYPE'},{av:'AV50UserRememberMeType',fld:'vUSERREMEMBERMETYPE',pic:''},{av:'AV49UserRememberMeTimeOut',fld:'vUSERREMEMBERMETIMEOUT',pic:'ZZZ9'},{av:'AV48UserRecoveryPasswordKeyTimeOut',fld:'vUSERRECOVERYPASSWORDKEYTIMEOUT',pic:'ZZZ9'},{ctrl:'vLOGOUTBEHAVIOR'},{av:'AV27LogoutBehavior',fld:'vLOGOUTBEHAVIOR',pic:''},{av:'AV28MinimumAmountCharactersInLogin',fld:'vMINIMUMAMOUNTCHARACTERSINLOGIN',pic:'Z9'},{av:'AV26LoginAttemptsToLockUser',fld:'vLOGINATTEMPTSTOLOCKUSER',pic:'Z9'},{av:'AV25LoginAttemptsToLockSession',fld:'vLOGINATTEMPTSTOLOCKSESSION',pic:'Z9'},{av:'AV51UserSessionCacheTimeout',fld:'vUSERSESSIONCACHETIMEOUT',pic:'ZZZZZ9'},{av:'AV33RepositoryCacheTimeout',fld:'vREPOSITORYCACHETIMEOUT',pic:'ZZZZZ9'},{av:'AV40SecurityAdministratorEmail',fld:'vSECURITYADMINISTRATOREMAIL',pic:'',hsh:true},{av:'AV8CanRegisterUsers',fld:'vCANREGISTERUSERS',pic:'',hsh:true},{ctrl:'vDEFAULTSECURITYPOLICYID'},{av:'AV11DefaultSecurityPolicyId',fld:'vDEFAULTSECURITYPOLICYID',pic:'ZZZZZZZZ9'},{ctrl:'vDEFAULTROLEID'},{av:'AV10DefaultRoleId',fld:'vDEFAULTROLEID',pic:'ZZZZZZZZZZZ9'},{ctrl:'vENABLETRACING'},{av:'AV13EnableTracing',fld:'vENABLETRACING',pic:'ZZZ9'},{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EvtParms["VALIDV_LOGOUTBEHAVIOR"] = [[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EvtParms["VALIDV_ENABLETRACING"] = [[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EvtParms["VALIDV_USERIDENTIFICATION"] = [[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EvtParms["VALIDV_USERACTIVATIONMETHOD"] = [[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EvtParms["VALIDV_GENERATESESSIONSTATISTICS"] = [[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EvtParms["VALIDV_USERREMEMBERMETYPE"] = [[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}],[{av:'AV43SessionExpiresOnIPChange',fld:'vSESSIONEXPIRESONIPCHANGE',pic:''},{av:'AV5AllowOauthAccess',fld:'vALLOWOAUTHACCESS',pic:''},{av:'AV52EnableWorkingAsGAMManagerRepo',fld:'vENABLEWORKINGASGAMMANAGERREPO',pic:''},{av:'AV46UserEmailisUnique',fld:'vUSEREMAILISUNIQUE',pic:''},{av:'AV34RequiredEmail',fld:'vREQUIREDEMAIL',pic:''},{av:'AV37RequiredPassword',fld:'vREQUIREDPASSWORD',pic:''},{av:'AV35RequiredFirstName',fld:'vREQUIREDFIRSTNAME',pic:''},{av:'AV36RequiredLastName',fld:'vREQUIREDLASTNAME',pic:''},{av:'AV20GiveAnonymousSession',fld:'vGIVEANONYMOUSSESSION',pic:''}]];
   this.EnterCtrl = ["CONFIRM"];
   this.setVCMap("AV40SecurityAdministratorEmail", "vSECURITYADMINISTRATOREMAIL", 0, "svchar", 100, 0);
   this.setVCMap("AV8CanRegisterUsers", "vCANREGISTERUSERS", 0, "boolean", 1, 0);
   this.setVCMap("AV31pId", "vPID", 0, "int", 12, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_repositoryconfiguration);});
