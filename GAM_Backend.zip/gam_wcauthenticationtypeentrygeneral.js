/*
               File: GAM_WCAuthenticationTypeEntryGeneral
        Description: Authentication Type Entry General
             Author: GeneXus .NET Core Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:18:14.58
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wcauthenticationtypeentrygeneral', true, function (CmpContext) {
   this.ServerClass =  "gam_wcauthenticationtypeentrygeneral" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV37TypeId=gx.fn.getControlValue("vTYPEID") ;
   };
   this.Validv_Functionid=function()
   {
      return this.validCliEvt("Validv_Functionid", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vFUNCTIONID");
         this.AnyError  = 0;
         if ( ! ( ( this.AV28FunctionId == "AuthenticationAndRoles" ) || ( this.AV28FunctionId == "OnlyAuthentication" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Function Id"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Wsversion=function()
   {
      return this.validCliEvt("Validv_Wsversion", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vWSVERSION");
         this.AnyError  = 0;
         if ( ! ( ( this.AV47WSVersion == "GAM10" ) || ( this.AV47WSVersion == "GAM20" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "WSVersion"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.Validv_Cusversion=function()
   {
      return this.validCliEvt("Validv_Cusversion", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vCUSVERSION");
         this.AnyError  = 0;
         if ( ! ( ( this.AV24CusVersion == "GAM10" ) || ( this.AV24CusVersion == "GAM20" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Cus Version"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.s112_client=function()
   {
      /* 'REFRESHAUTHENTICATIONTYPE' Routine */
      gx.fn.setCtrlProperty("vSITEURL","Visible", true );
      gx.fn.setCtrlProperty("TBLIMPERSONATE","Visible", true );
      gx.fn.setCtrlProperty("TBLCLIENTIDSECRET","Visible", false );
      gx.fn.setCtrlProperty("TBLCLIENTLOCALSERVER","Visible", false );
      gx.fn.setCtrlProperty("TBLSCOPES","Visible", false );
      gx.fn.setCtrlProperty("TBLAUTHTYPENAME","Visible", false );
      gx.fn.setCtrlProperty("TBLCOMMONADDITIONAL","Visible", false );
      gx.fn.setCtrlProperty("TBLSERVERHOST","Visible", false );
      gx.fn.setCtrlProperty("TBLTWITTER","Visible", false );
      gx.fn.setCtrlProperty("TBLWEBSERVICE","Visible", false );
      gx.fn.setCtrlProperty("TBLEXTERNAL","Visible", false );
      if ( ( this.AV37TypeId == "AppleID" ) || ( this.AV37TypeId == "Facebook" ) || ( this.AV37TypeId == "Google" ) || ( this.AV37TypeId == "WeChat" ) || ( this.AV37TypeId == "Twitter" ) )
      {
         this.AV28FunctionId =  "OnlyAuthentication"  ;
         gx.fn.setCtrlProperty("vFUNCTIONID","Enabled", false );
      }
      else
      {
         gx.fn.setCtrlProperty("vFUNCTIONID","Enabled", true );
      }
      if ( this.AV37TypeId == "GAMLocal" )
      {
         gx.fn.setCtrlProperty("TBLIMPERSONATE","Visible", false );
      }
      else if ( ( this.AV37TypeId == "AppleID" ) || ( this.AV37TypeId == "Facebook" ) || ( this.AV37TypeId == "Google" ) || ( this.AV37TypeId == "WeChat" ) || ( this.AV37TypeId == "GAMRemote" ) )
      {
         gx.fn.setCtrlProperty("TBLCLIENTIDSECRET","Visible", true );
         gx.fn.setCtrlProperty("TBLCLIENTLOCALSERVER","Visible", true );
         gx.fn.setCtrlProperty("TBLCOMMONADDITIONAL","Visible", true );
         if ( this.AV37TypeId == "WeChat" )
         {
            gx.fn.setCtrlProperty("vVERSIONPATH","Visible", false );
         }
         if ( this.AV37TypeId == "GAMRemote" )
         {
            gx.fn.setCtrlProperty("vVERSIONPATH","Visible", false );
            gx.fn.setCtrlProperty("TBLSCOPES","Visible", true );
            gx.fn.setCtrlProperty("TBLSERVERHOST","Visible", true );
         }
      }
      else if ( this.AV37TypeId == "GAMRemoteRest" )
      {
         gx.fn.setCtrlProperty("TBLCLIENTIDSECRET","Visible", true );
         gx.fn.setCtrlProperty("TBLSCOPES","Visible", true );
         gx.fn.setCtrlProperty("TBLCOMMONADDITIONAL","Visible", true );
         gx.fn.setCtrlProperty("TBLAUTHTYPENAME","Visible", true );
         gx.fn.setCtrlProperty("TBLSERVERHOST","Visible", true );
      }
      else if ( this.AV37TypeId == "Twitter" )
      {
         this.AV28FunctionId =  "OnlyAuthentication"  ;
         gx.fn.setCtrlProperty("vFUNCTIONID","Enabled", false );
         gx.fn.setCtrlProperty("TBLTWITTER","Visible", true );
      }
      else if ( this.AV37TypeId == "ExternalWebService" )
      {
         gx.fn.setCtrlProperty("TBLWEBSERVICE","Visible", true );
      }
      else if ( this.AV37TypeId == "Custom" )
      {
         gx.fn.setCtrlProperty("TBLEXTERNAL","Visible", true );
      }
   };
   this.e122q2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e132q2_client=function()
   {
      /* 'GenerateKey' Routine */
      return this.executeServerEvent("'GENERATEKEY'", false, null, false, false);
   };
   this.e142q2_client=function()
   {
      /* 'GenerateKeyCustom' Routine */
      return this.executeServerEvent("'GENERATEKEYCUSTOM'", false, null, false, false);
   };
   this.e162q1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234];
   this.GXLastCtrlId =234;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE2",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TBLDATA",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV34Name",gxold:"OV34Name",gxvar:"AV34Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV34Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV34Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV34Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV34Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 14 , function() {
   });
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id:19 ,lvl:0,type:"char",len:30,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Functionid,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFUNCTIONID",gxz:"ZV28FunctionId",gxold:"OV28FunctionId",gxvar:"AV28FunctionId",ucs:[],op:[19],ip:[19],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV28FunctionId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV28FunctionId=Value},v2c:function(){gx.fn.setComboBoxValue("vFUNCTIONID",gx.O.AV28FunctionId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV28FunctionId=this.val()},val:function(){return gx.fn.getControlValue("vFUNCTIONID")},nac:gx.falseFn};
   this.declareDomainHdlr( 19 , function() {
   });
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISENABLE",gxz:"ZV33IsEnable",gxold:"OV33IsEnable",gxvar:"AV33IsEnable",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV33IsEnable=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV33IsEnable=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vISENABLE",gx.O.AV33IsEnable,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV33IsEnable=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vISENABLE")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 24 , function() {
   });
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id:29 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",gxz:"ZV25Dsc",gxold:"OV25Dsc",gxvar:"AV25Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV25Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV25Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV25Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV25Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 29 , function() {
   });
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id:34 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSMALLIMAGENAME",gxz:"ZV36SmallImageName",gxold:"OV36SmallImageName",gxvar:"AV36SmallImageName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV36SmallImageName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV36SmallImageName=Value},v2c:function(){gx.fn.setControlValue("vSMALLIMAGENAME",gx.O.AV36SmallImageName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV36SmallImageName=this.val()},val:function(){return gx.fn.getControlValue("vSMALLIMAGENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 34 , function() {
   });
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id:39 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBIGIMAGENAME",gxz:"ZV14BigImageName",gxold:"OV14BigImageName",gxvar:"AV14BigImageName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14BigImageName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14BigImageName=Value},v2c:function(){gx.fn.setControlValue("vBIGIMAGENAME",gx.O.AV14BigImageName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14BigImageName=this.val()},val:function(){return gx.fn.getControlValue("vBIGIMAGENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 39 , function() {
   });
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"TBLIMPERSONATE",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id:47 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vIMPERSONATE",gxz:"ZV32Impersonate",gxold:"OV32Impersonate",gxvar:"AV32Impersonate",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV32Impersonate=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32Impersonate=Value},v2c:function(){gx.fn.setControlValue("vIMPERSONATE",gx.O.AV32Impersonate,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV32Impersonate=this.val()},val:function(){return gx.fn.getControlValue("vIMPERSONATE")},nac:gx.falseFn};
   this.declareDomainHdlr( 47 , function() {
   });
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"TBLCLIENTIDSECRET",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id:55 ,lvl:0,type:"svchar",len:400,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTID",gxz:"ZV16ClientId",gxold:"OV16ClientId",gxvar:"AV16ClientId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16ClientId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16ClientId=Value},v2c:function(){gx.fn.setControlValue("vCLIENTID",gx.O.AV16ClientId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16ClientId=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTID")},nac:gx.falseFn};
   this.declareDomainHdlr( 55 , function() {
   });
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id:60 ,lvl:0,type:"svchar",len:400,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCLIENTSECRET",gxz:"ZV17ClientSecret",gxold:"OV17ClientSecret",gxvar:"AV17ClientSecret",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV17ClientSecret=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV17ClientSecret=Value},v2c:function(){gx.fn.setControlValue("vCLIENTSECRET",gx.O.AV17ClientSecret,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV17ClientSecret=this.val()},val:function(){return gx.fn.getControlValue("vCLIENTSECRET")},nac:gx.falseFn};
   this.declareDomainHdlr( 60 , function() {
   });
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id:65 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vVERSIONPATH",gxz:"ZV52VersionPath",gxold:"OV52VersionPath",gxvar:"AV52VersionPath",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV52VersionPath=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV52VersionPath=Value},v2c:function(){gx.fn.setControlValue("vVERSIONPATH",gx.O.AV52VersionPath,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV52VersionPath=this.val()},val:function(){return gx.fn.getControlValue("vVERSIONPATH")},nac:gx.falseFn};
   this.declareDomainHdlr( 65 , function() {
   });
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"TBLCLIENTLOCALSERVER",grid:0};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id:73 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSITEURL",gxz:"ZV35SiteURL",gxold:"OV35SiteURL",gxvar:"AV35SiteURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV35SiteURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV35SiteURL=Value},v2c:function(){gx.fn.setControlValue("vSITEURL",gx.O.AV35SiteURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV35SiteURL=this.val()},val:function(){return gx.fn.getControlValue("vSITEURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 73 , function() {
   });
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"TBLTWITTER",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"",grid:0};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"",grid:0};
   GXValidFnc[81]={ id:81 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONSUMERKEY",gxz:"ZV18ConsumerKey",gxold:"OV18ConsumerKey",gxvar:"AV18ConsumerKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18ConsumerKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18ConsumerKey=Value},v2c:function(){gx.fn.setControlValue("vCONSUMERKEY",gx.O.AV18ConsumerKey,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV18ConsumerKey=this.val()},val:function(){return gx.fn.getControlValue("vCONSUMERKEY")},nac:gx.falseFn};
   GXValidFnc[82]={ id: 82, fld:"",grid:0};
   GXValidFnc[83]={ id: 83, fld:"",grid:0};
   GXValidFnc[84]={ id: 84, fld:"",grid:0};
   GXValidFnc[85]={ id: 85, fld:"",grid:0};
   GXValidFnc[86]={ id:86 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCONSUMERSECRET",gxz:"ZV19ConsumerSecret",gxold:"OV19ConsumerSecret",gxvar:"AV19ConsumerSecret",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV19ConsumerSecret=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV19ConsumerSecret=Value},v2c:function(){gx.fn.setControlValue("vCONSUMERSECRET",gx.O.AV19ConsumerSecret,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV19ConsumerSecret=this.val()},val:function(){return gx.fn.getControlValue("vCONSUMERSECRET")},nac:gx.falseFn};
   GXValidFnc[87]={ id: 87, fld:"",grid:0};
   GXValidFnc[88]={ id: 88, fld:"",grid:0};
   GXValidFnc[89]={ id: 89, fld:"",grid:0};
   GXValidFnc[90]={ id: 90, fld:"",grid:0};
   GXValidFnc[91]={ id:91 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCALLBACKURL",gxz:"ZV15CallbackURL",gxold:"OV15CallbackURL",gxvar:"AV15CallbackURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV15CallbackURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV15CallbackURL=Value},v2c:function(){gx.fn.setControlValue("vCALLBACKURL",gx.O.AV15CallbackURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV15CallbackURL=this.val()},val:function(){return gx.fn.getControlValue("vCALLBACKURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 91 , function() {
   });
   GXValidFnc[92]={ id: 92, fld:"",grid:0};
   GXValidFnc[93]={ id: 93, fld:"",grid:0};
   GXValidFnc[94]={ id: 94, fld:"TBLSCOPES",grid:0};
   GXValidFnc[95]={ id: 95, fld:"",grid:0};
   GXValidFnc[96]={ id: 96, fld:"",grid:0};
   GXValidFnc[97]={ id: 97, fld:"",grid:0};
   GXValidFnc[98]={ id: 98, fld:"",grid:0};
   GXValidFnc[99]={ id:99 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADDUSERADDITIONALDATASCOPE",gxz:"ZV54AddUserAdditionalDataScope",gxold:"OV54AddUserAdditionalDataScope",gxvar:"AV54AddUserAdditionalDataScope",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV54AddUserAdditionalDataScope=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV54AddUserAdditionalDataScope=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vADDUSERADDITIONALDATASCOPE",gx.O.AV54AddUserAdditionalDataScope,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV54AddUserAdditionalDataScope=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vADDUSERADDITIONALDATASCOPE")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[100]={ id: 100, fld:"",grid:0};
   GXValidFnc[101]={ id: 101, fld:"",grid:0};
   GXValidFnc[102]={ id: 102, fld:"",grid:0};
   GXValidFnc[103]={ id:103 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADDINITIALPROPERTIESSCOPE",gxz:"ZV50AddInitialPropertiesScope",gxold:"OV50AddInitialPropertiesScope",gxvar:"AV50AddInitialPropertiesScope",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV50AddInitialPropertiesScope=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV50AddInitialPropertiesScope=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vADDINITIALPROPERTIESSCOPE",gx.O.AV50AddInitialPropertiesScope,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV50AddInitialPropertiesScope=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vADDINITIALPROPERTIESSCOPE")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[104]={ id: 104, fld:"",grid:0};
   GXValidFnc[105]={ id: 105, fld:"",grid:0};
   GXValidFnc[106]={ id: 106, fld:"TBLCOMMONADDITIONAL",grid:0};
   GXValidFnc[107]={ id: 107, fld:"",grid:0};
   GXValidFnc[108]={ id: 108, fld:"",grid:0};
   GXValidFnc[109]={ id: 109, fld:"",grid:0};
   GXValidFnc[110]={ id: 110, fld:"",grid:0};
   GXValidFnc[111]={ id:111 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vADDITIONALSCOPE",gxz:"ZV5AdditionalScope",gxold:"OV5AdditionalScope",gxvar:"AV5AdditionalScope",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV5AdditionalScope=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5AdditionalScope=Value},v2c:function(){gx.fn.setControlValue("vADDITIONALSCOPE",gx.O.AV5AdditionalScope,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV5AdditionalScope=this.val()},val:function(){return gx.fn.getControlValue("vADDITIONALSCOPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 111 , function() {
   });
   GXValidFnc[112]={ id: 112, fld:"",grid:0};
   GXValidFnc[113]={ id: 113, fld:"",grid:0};
   GXValidFnc[114]={ id: 114, fld:"TBLAUTHTYPENAME",grid:0};
   GXValidFnc[115]={ id: 115, fld:"",grid:0};
   GXValidFnc[116]={ id: 116, fld:"",grid:0};
   GXValidFnc[117]={ id: 117, fld:"",grid:0};
   GXValidFnc[118]={ id: 118, fld:"",grid:0};
   GXValidFnc[119]={ id:119 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMRAUTHENTICATIONTYPENAME",gxz:"ZV53GAMRAuthenticationTypeName",gxold:"OV53GAMRAuthenticationTypeName",gxvar:"AV53GAMRAuthenticationTypeName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV53GAMRAuthenticationTypeName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV53GAMRAuthenticationTypeName=Value},v2c:function(){gx.fn.setControlValue("vGAMRAUTHENTICATIONTYPENAME",gx.O.AV53GAMRAuthenticationTypeName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV53GAMRAuthenticationTypeName=this.val()},val:function(){return gx.fn.getControlValue("vGAMRAUTHENTICATIONTYPENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 119 , function() {
   });
   GXValidFnc[120]={ id: 120, fld:"",grid:0};
   GXValidFnc[121]={ id: 121, fld:"",grid:0};
   GXValidFnc[122]={ id: 122, fld:"TBLSERVERHOST",grid:0};
   GXValidFnc[123]={ id: 123, fld:"",grid:0};
   GXValidFnc[124]={ id: 124, fld:"",grid:0};
   GXValidFnc[125]={ id: 125, fld:"",grid:0};
   GXValidFnc[126]={ id: 126, fld:"",grid:0};
   GXValidFnc[127]={ id:127 ,lvl:0,type:"svchar",len:2048,dec:250,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMRSERVERURL",gxz:"ZV31GAMRServerURL",gxold:"OV31GAMRServerURL",gxvar:"AV31GAMRServerURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV31GAMRServerURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV31GAMRServerURL=Value},v2c:function(){gx.fn.setControlValue("vGAMRSERVERURL",gx.O.AV31GAMRServerURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV31GAMRServerURL=this.val()},val:function(){return gx.fn.getControlValue("vGAMRSERVERURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 127 , function() {
   });
   GXValidFnc[128]={ id: 128, fld:"",grid:0};
   GXValidFnc[129]={ id: 129, fld:"",grid:0};
   GXValidFnc[130]={ id: 130, fld:"",grid:0};
   GXValidFnc[131]={ id: 131, fld:"",grid:0};
   GXValidFnc[132]={ id:132 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMRPRIVATEENCRYPTKEY",gxz:"ZV29GAMRPrivateEncryptKey",gxold:"OV29GAMRPrivateEncryptKey",gxvar:"AV29GAMRPrivateEncryptKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV29GAMRPrivateEncryptKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV29GAMRPrivateEncryptKey=Value},v2c:function(){gx.fn.setControlValue("vGAMRPRIVATEENCRYPTKEY",gx.O.AV29GAMRPrivateEncryptKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV29GAMRPrivateEncryptKey=this.val()},val:function(){return gx.fn.getControlValue("vGAMRPRIVATEENCRYPTKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 132 , function() {
   });
   GXValidFnc[133]={ id: 133, fld:"",grid:0};
   GXValidFnc[134]={ id: 134, fld:"FORMCELL",grid:0};
   GXValidFnc[135]={ id: 135, fld:"",grid:0};
   GXValidFnc[136]={ id: 136, fld:"",grid:0};
   GXValidFnc[137]={ id:137 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGAMRREPOSITORYGUID",gxz:"ZV30GAMRRepositoryGUID",gxold:"OV30GAMRRepositoryGUID",gxvar:"AV30GAMRRepositoryGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV30GAMRRepositoryGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV30GAMRRepositoryGUID=Value},v2c:function(){gx.fn.setControlValue("vGAMRREPOSITORYGUID",gx.O.AV30GAMRRepositoryGUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV30GAMRRepositoryGUID=this.val()},val:function(){return gx.fn.getControlValue("vGAMRREPOSITORYGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 137 , function() {
   });
   GXValidFnc[138]={ id: 138, fld:"",grid:0};
   GXValidFnc[139]={ id: 139, fld:"",grid:0};
   GXValidFnc[140]={ id: 140, fld:"",grid:0};
   GXValidFnc[141]={ id: 141, fld:"",grid:0};
   GXValidFnc[142]={ id:142 ,lvl:0,type:"boolean",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vAUTOVALIDATEEXTERNALTOKENANDREFRESH",gxz:"ZV57AutovalidateExternalTokenAndRefresh",gxold:"OV57AutovalidateExternalTokenAndRefresh",gxvar:"AV57AutovalidateExternalTokenAndRefresh",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV57AutovalidateExternalTokenAndRefresh=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV57AutovalidateExternalTokenAndRefresh=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vAUTOVALIDATEEXTERNALTOKENANDREFRESH",gx.O.AV57AutovalidateExternalTokenAndRefresh,true);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV57AutovalidateExternalTokenAndRefresh=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vAUTOVALIDATEEXTERNALTOKENANDREFRESH")},nac:gx.falseFn,values:['true','false']};
   this.declareDomainHdlr( 142 , function() {
   });
   GXValidFnc[143]={ id: 143, fld:"",grid:0};
   GXValidFnc[144]={ id: 144, fld:"",grid:0};
   GXValidFnc[145]={ id: 145, fld:"TBLWEBSERVICE",grid:0};
   GXValidFnc[146]={ id: 146, fld:"",grid:0};
   GXValidFnc[147]={ id: 147, fld:"",grid:0};
   GXValidFnc[148]={ id: 148, fld:"",grid:0};
   GXValidFnc[149]={ id: 149, fld:"",grid:0};
   GXValidFnc[150]={ id:150 ,lvl:0,type:"char",len:20,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Wsversion,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSVERSION",gxz:"ZV47WSVersion",gxold:"OV47WSVersion",gxvar:"AV47WSVersion",ucs:[],op:[150],ip:[150],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV47WSVersion=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV47WSVersion=Value},v2c:function(){gx.fn.setComboBoxValue("vWSVERSION",gx.O.AV47WSVersion);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV47WSVersion=this.val()},val:function(){return gx.fn.getControlValue("vWSVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 150 , function() {
   });
   GXValidFnc[151]={ id: 151, fld:"",grid:0};
   GXValidFnc[152]={ id: 152, fld:"",grid:0};
   GXValidFnc[153]={ id: 153, fld:"",grid:0};
   GXValidFnc[154]={ id: 154, fld:"",grid:0};
   GXValidFnc[155]={ id:155 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSPRIVATEENCRYPTKEY",gxz:"ZV41WSPrivateEncryptKey",gxold:"OV41WSPrivateEncryptKey",gxvar:"AV41WSPrivateEncryptKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV41WSPrivateEncryptKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV41WSPrivateEncryptKey=Value},v2c:function(){gx.fn.setControlValue("vWSPRIVATEENCRYPTKEY",gx.O.AV41WSPrivateEncryptKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV41WSPrivateEncryptKey=this.val()},val:function(){return gx.fn.getControlValue("vWSPRIVATEENCRYPTKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 155 , function() {
   });
   GXValidFnc[156]={ id: 156, fld:"",grid:0};
   GXValidFnc[157]={ id: 157, fld:"BTNGENKEY",grid:0,evt:"e132q2_client"};
   GXValidFnc[158]={ id: 158, fld:"",grid:0};
   GXValidFnc[159]={ id: 159, fld:"",grid:0};
   GXValidFnc[160]={ id: 160, fld:"",grid:0};
   GXValidFnc[161]={ id: 161, fld:"",grid:0};
   GXValidFnc[162]={ id:162 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSSERVERNAME",gxz:"ZV43WSServerName",gxold:"OV43WSServerName",gxvar:"AV43WSServerName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV43WSServerName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV43WSServerName=Value},v2c:function(){gx.fn.setControlValue("vWSSERVERNAME",gx.O.AV43WSServerName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV43WSServerName=this.val()},val:function(){return gx.fn.getControlValue("vWSSERVERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 162 , function() {
   });
   GXValidFnc[163]={ id: 163, fld:"",grid:0};
   GXValidFnc[164]={ id: 164, fld:"",grid:0};
   GXValidFnc[165]={ id: 165, fld:"",grid:0};
   GXValidFnc[166]={ id: 166, fld:"",grid:0};
   GXValidFnc[167]={ id:167 ,lvl:0,type:"int",len:5,dec:0,sign:false,pic:"ZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSSERVERPORT",gxz:"ZV44WSServerPort",gxold:"OV44WSServerPort",gxvar:"AV44WSServerPort",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV44WSServerPort=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV44WSServerPort=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vWSSERVERPORT",gx.O.AV44WSServerPort,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV44WSServerPort=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vWSSERVERPORT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[168]={ id: 168, fld:"",grid:0};
   GXValidFnc[169]={ id: 169, fld:"",grid:0};
   GXValidFnc[170]={ id: 170, fld:"",grid:0};
   GXValidFnc[171]={ id: 171, fld:"",grid:0};
   GXValidFnc[172]={ id:172 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSSERVERBASEURL",gxz:"ZV42WSServerBaseURL",gxold:"OV42WSServerBaseURL",gxvar:"AV42WSServerBaseURL",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV42WSServerBaseURL=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV42WSServerBaseURL=Value},v2c:function(){gx.fn.setControlValue("vWSSERVERBASEURL",gx.O.AV42WSServerBaseURL,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV42WSServerBaseURL=this.val()},val:function(){return gx.fn.getControlValue("vWSSERVERBASEURL")},nac:gx.falseFn};
   this.declareDomainHdlr( 172 , function() {
   });
   GXValidFnc[173]={ id: 173, fld:"",grid:0};
   GXValidFnc[174]={ id: 174, fld:"",grid:0};
   GXValidFnc[175]={ id: 175, fld:"",grid:0};
   GXValidFnc[176]={ id: 176, fld:"",grid:0};
   GXValidFnc[177]={ id:177 ,lvl:0,type:"int",len:1,dec:0,sign:false,pic:"9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSSERVERSECUREPROTOCOL",gxz:"ZV45WSServerSecureProtocol",gxold:"OV45WSServerSecureProtocol",gxvar:"AV45WSServerSecureProtocol",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV45WSServerSecureProtocol=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV45WSServerSecureProtocol=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vWSSERVERSECUREPROTOCOL",gx.O.AV45WSServerSecureProtocol)},c2v:function(){if(this.val()!==undefined)gx.O.AV45WSServerSecureProtocol=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vWSSERVERSECUREPROTOCOL",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[178]={ id: 178, fld:"",grid:0};
   GXValidFnc[179]={ id: 179, fld:"",grid:0};
   GXValidFnc[180]={ id: 180, fld:"",grid:0};
   GXValidFnc[181]={ id: 181, fld:"",grid:0};
   GXValidFnc[182]={ id:182 ,lvl:0,type:"int",len:5,dec:0,sign:false,pic:"ZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSTIMEOUT",gxz:"ZV46WSTimeout",gxold:"OV46WSTimeout",gxvar:"AV46WSTimeout",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV46WSTimeout=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV46WSTimeout=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vWSTIMEOUT",gx.O.AV46WSTimeout,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV46WSTimeout=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vWSTIMEOUT",gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[183]={ id: 183, fld:"",grid:0};
   GXValidFnc[184]={ id: 184, fld:"",grid:0};
   GXValidFnc[185]={ id: 185, fld:"",grid:0};
   GXValidFnc[186]={ id: 186, fld:"",grid:0};
   GXValidFnc[187]={ id:187 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSPACKAGE",gxz:"ZV40WSPackage",gxold:"OV40WSPackage",gxvar:"AV40WSPackage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV40WSPackage=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV40WSPackage=Value},v2c:function(){gx.fn.setControlValue("vWSPACKAGE",gx.O.AV40WSPackage,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV40WSPackage=this.val()},val:function(){return gx.fn.getControlValue("vWSPACKAGE")},nac:gx.falseFn};
   this.declareDomainHdlr( 187 , function() {
   });
   GXValidFnc[188]={ id: 188, fld:"",grid:0};
   GXValidFnc[189]={ id: 189, fld:"",grid:0};
   GXValidFnc[190]={ id: 190, fld:"",grid:0};
   GXValidFnc[191]={ id: 191, fld:"",grid:0};
   GXValidFnc[192]={ id:192 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSNAME",gxz:"ZV39WSName",gxold:"OV39WSName",gxvar:"AV39WSName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV39WSName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV39WSName=Value},v2c:function(){gx.fn.setControlValue("vWSNAME",gx.O.AV39WSName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV39WSName=this.val()},val:function(){return gx.fn.getControlValue("vWSNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 192 , function() {
   });
   GXValidFnc[193]={ id: 193, fld:"",grid:0};
   GXValidFnc[194]={ id: 194, fld:"",grid:0};
   GXValidFnc[195]={ id: 195, fld:"",grid:0};
   GXValidFnc[196]={ id: 196, fld:"",grid:0};
   GXValidFnc[197]={ id:197 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWSEXTENSION",gxz:"ZV38WSExtension",gxold:"OV38WSExtension",gxvar:"AV38WSExtension",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV38WSExtension=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV38WSExtension=Value},v2c:function(){gx.fn.setControlValue("vWSEXTENSION",gx.O.AV38WSExtension,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV38WSExtension=this.val()},val:function(){return gx.fn.getControlValue("vWSEXTENSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 197 , function() {
   });
   GXValidFnc[198]={ id: 198, fld:"",grid:0};
   GXValidFnc[199]={ id: 199, fld:"",grid:0};
   GXValidFnc[200]={ id: 200, fld:"TBLEXTERNAL",grid:0};
   GXValidFnc[201]={ id: 201, fld:"",grid:0};
   GXValidFnc[202]={ id: 202, fld:"",grid:0};
   GXValidFnc[203]={ id: 203, fld:"",grid:0};
   GXValidFnc[204]={ id: 204, fld:"",grid:0};
   GXValidFnc[205]={ id:205 ,lvl:0,type:"char",len:20,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Cusversion,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSVERSION",gxz:"ZV24CusVersion",gxold:"OV24CusVersion",gxvar:"AV24CusVersion",ucs:[],op:[205],ip:[205],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV24CusVersion=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV24CusVersion=Value},v2c:function(){gx.fn.setComboBoxValue("vCUSVERSION",gx.O.AV24CusVersion);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV24CusVersion=this.val()},val:function(){return gx.fn.getControlValue("vCUSVERSION")},nac:gx.falseFn};
   this.declareDomainHdlr( 205 , function() {
   });
   GXValidFnc[206]={ id: 206, fld:"",grid:0};
   GXValidFnc[207]={ id: 207, fld:"",grid:0};
   GXValidFnc[208]={ id: 208, fld:"",grid:0};
   GXValidFnc[209]={ id: 209, fld:"",grid:0};
   GXValidFnc[210]={ id:210 ,lvl:0,type:"char",len:32,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSPRIVATEENCRYPTKEY",gxz:"ZV23CusPrivateEncryptKey",gxold:"OV23CusPrivateEncryptKey",gxvar:"AV23CusPrivateEncryptKey",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV23CusPrivateEncryptKey=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV23CusPrivateEncryptKey=Value},v2c:function(){gx.fn.setControlValue("vCUSPRIVATEENCRYPTKEY",gx.O.AV23CusPrivateEncryptKey,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV23CusPrivateEncryptKey=this.val()},val:function(){return gx.fn.getControlValue("vCUSPRIVATEENCRYPTKEY")},nac:gx.falseFn};
   this.declareDomainHdlr( 210 , function() {
   });
   GXValidFnc[211]={ id: 211, fld:"",grid:0};
   GXValidFnc[212]={ id: 212, fld:"BTNGENKEYCUSTOM",grid:0,evt:"e142q2_client"};
   GXValidFnc[213]={ id: 213, fld:"",grid:0};
   GXValidFnc[214]={ id: 214, fld:"",grid:0};
   GXValidFnc[215]={ id: 215, fld:"",grid:0};
   GXValidFnc[216]={ id: 216, fld:"",grid:0};
   GXValidFnc[217]={ id:217 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSFILENAME",gxz:"ZV21CusFileName",gxold:"OV21CusFileName",gxvar:"AV21CusFileName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV21CusFileName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV21CusFileName=Value},v2c:function(){gx.fn.setControlValue("vCUSFILENAME",gx.O.AV21CusFileName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV21CusFileName=this.val()},val:function(){return gx.fn.getControlValue("vCUSFILENAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 217 , function() {
   });
   GXValidFnc[218]={ id: 218, fld:"",grid:0};
   GXValidFnc[219]={ id: 219, fld:"",grid:0};
   GXValidFnc[220]={ id: 220, fld:"",grid:0};
   GXValidFnc[221]={ id: 221, fld:"",grid:0};
   GXValidFnc[222]={ id:222 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSPACKAGE",gxz:"ZV22CusPackage",gxold:"OV22CusPackage",gxvar:"AV22CusPackage",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV22CusPackage=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV22CusPackage=Value},v2c:function(){gx.fn.setControlValue("vCUSPACKAGE",gx.O.AV22CusPackage,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV22CusPackage=this.val()},val:function(){return gx.fn.getControlValue("vCUSPACKAGE")},nac:gx.falseFn};
   this.declareDomainHdlr( 222 , function() {
   });
   GXValidFnc[223]={ id: 223, fld:"",grid:0};
   GXValidFnc[224]={ id: 224, fld:"",grid:0};
   GXValidFnc[225]={ id: 225, fld:"",grid:0};
   GXValidFnc[226]={ id: 226, fld:"",grid:0};
   GXValidFnc[227]={ id:227 ,lvl:0,type:"char",len:120,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCUSCLASSNAME",gxz:"ZV20CusClassName",gxold:"OV20CusClassName",gxvar:"AV20CusClassName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV20CusClassName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20CusClassName=Value},v2c:function(){gx.fn.setControlValue("vCUSCLASSNAME",gx.O.AV20CusClassName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20CusClassName=this.val()},val:function(){return gx.fn.getControlValue("vCUSCLASSNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 227 , function() {
   });
   GXValidFnc[228]={ id: 228, fld:"",grid:0};
   GXValidFnc[229]={ id: 229, fld:"",grid:0};
   GXValidFnc[230]={ id: 230, fld:"",grid:0};
   GXValidFnc[231]={ id: 231, fld:"",grid:0};
   GXValidFnc[232]={ id: 232, fld:"BTNCANCEL",grid:0,evt:"e162q1_client"};
   GXValidFnc[233]={ id: 233, fld:"",grid:0};
   GXValidFnc[234]={ id: 234, fld:"BTNCONFIRM",grid:0,evt:"e122q2_client",std:"ENTER"};
   this.AV34Name = "" ;
   this.ZV34Name = "" ;
   this.OV34Name = "" ;
   this.AV28FunctionId = "" ;
   this.ZV28FunctionId = "" ;
   this.OV28FunctionId = "" ;
   this.AV33IsEnable = false ;
   this.ZV33IsEnable = false ;
   this.OV33IsEnable = false ;
   this.AV25Dsc = "" ;
   this.ZV25Dsc = "" ;
   this.OV25Dsc = "" ;
   this.AV36SmallImageName = "" ;
   this.ZV36SmallImageName = "" ;
   this.OV36SmallImageName = "" ;
   this.AV14BigImageName = "" ;
   this.ZV14BigImageName = "" ;
   this.OV14BigImageName = "" ;
   this.AV32Impersonate = "" ;
   this.ZV32Impersonate = "" ;
   this.OV32Impersonate = "" ;
   this.AV16ClientId = "" ;
   this.ZV16ClientId = "" ;
   this.OV16ClientId = "" ;
   this.AV17ClientSecret = "" ;
   this.ZV17ClientSecret = "" ;
   this.OV17ClientSecret = "" ;
   this.AV52VersionPath = "" ;
   this.ZV52VersionPath = "" ;
   this.OV52VersionPath = "" ;
   this.AV35SiteURL = "" ;
   this.ZV35SiteURL = "" ;
   this.OV35SiteURL = "" ;
   this.AV18ConsumerKey = "" ;
   this.ZV18ConsumerKey = "" ;
   this.OV18ConsumerKey = "" ;
   this.AV19ConsumerSecret = "" ;
   this.ZV19ConsumerSecret = "" ;
   this.OV19ConsumerSecret = "" ;
   this.AV15CallbackURL = "" ;
   this.ZV15CallbackURL = "" ;
   this.OV15CallbackURL = "" ;
   this.AV54AddUserAdditionalDataScope = false ;
   this.ZV54AddUserAdditionalDataScope = false ;
   this.OV54AddUserAdditionalDataScope = false ;
   this.AV50AddInitialPropertiesScope = false ;
   this.ZV50AddInitialPropertiesScope = false ;
   this.OV50AddInitialPropertiesScope = false ;
   this.AV5AdditionalScope = "" ;
   this.ZV5AdditionalScope = "" ;
   this.OV5AdditionalScope = "" ;
   this.AV53GAMRAuthenticationTypeName = "" ;
   this.ZV53GAMRAuthenticationTypeName = "" ;
   this.OV53GAMRAuthenticationTypeName = "" ;
   this.AV31GAMRServerURL = "" ;
   this.ZV31GAMRServerURL = "" ;
   this.OV31GAMRServerURL = "" ;
   this.AV29GAMRPrivateEncryptKey = "" ;
   this.ZV29GAMRPrivateEncryptKey = "" ;
   this.OV29GAMRPrivateEncryptKey = "" ;
   this.AV30GAMRRepositoryGUID = "" ;
   this.ZV30GAMRRepositoryGUID = "" ;
   this.OV30GAMRRepositoryGUID = "" ;
   this.AV57AutovalidateExternalTokenAndRefresh = false ;
   this.ZV57AutovalidateExternalTokenAndRefresh = false ;
   this.OV57AutovalidateExternalTokenAndRefresh = false ;
   this.AV47WSVersion = "" ;
   this.ZV47WSVersion = "" ;
   this.OV47WSVersion = "" ;
   this.AV41WSPrivateEncryptKey = "" ;
   this.ZV41WSPrivateEncryptKey = "" ;
   this.OV41WSPrivateEncryptKey = "" ;
   this.AV43WSServerName = "" ;
   this.ZV43WSServerName = "" ;
   this.OV43WSServerName = "" ;
   this.AV44WSServerPort = 0 ;
   this.ZV44WSServerPort = 0 ;
   this.OV44WSServerPort = 0 ;
   this.AV42WSServerBaseURL = "" ;
   this.ZV42WSServerBaseURL = "" ;
   this.OV42WSServerBaseURL = "" ;
   this.AV45WSServerSecureProtocol = 0 ;
   this.ZV45WSServerSecureProtocol = 0 ;
   this.OV45WSServerSecureProtocol = 0 ;
   this.AV46WSTimeout = 0 ;
   this.ZV46WSTimeout = 0 ;
   this.OV46WSTimeout = 0 ;
   this.AV40WSPackage = "" ;
   this.ZV40WSPackage = "" ;
   this.OV40WSPackage = "" ;
   this.AV39WSName = "" ;
   this.ZV39WSName = "" ;
   this.OV39WSName = "" ;
   this.AV38WSExtension = "" ;
   this.ZV38WSExtension = "" ;
   this.OV38WSExtension = "" ;
   this.AV24CusVersion = "" ;
   this.ZV24CusVersion = "" ;
   this.OV24CusVersion = "" ;
   this.AV23CusPrivateEncryptKey = "" ;
   this.ZV23CusPrivateEncryptKey = "" ;
   this.OV23CusPrivateEncryptKey = "" ;
   this.AV21CusFileName = "" ;
   this.ZV21CusFileName = "" ;
   this.OV21CusFileName = "" ;
   this.AV22CusPackage = "" ;
   this.ZV22CusPackage = "" ;
   this.OV22CusPackage = "" ;
   this.AV20CusClassName = "" ;
   this.ZV20CusClassName = "" ;
   this.OV20CusClassName = "" ;
   this.AV34Name = "" ;
   this.AV28FunctionId = "" ;
   this.AV33IsEnable = false ;
   this.AV25Dsc = "" ;
   this.AV36SmallImageName = "" ;
   this.AV14BigImageName = "" ;
   this.AV32Impersonate = "" ;
   this.AV16ClientId = "" ;
   this.AV17ClientSecret = "" ;
   this.AV52VersionPath = "" ;
   this.AV35SiteURL = "" ;
   this.AV18ConsumerKey = "" ;
   this.AV19ConsumerSecret = "" ;
   this.AV15CallbackURL = "" ;
   this.AV54AddUserAdditionalDataScope = false ;
   this.AV50AddInitialPropertiesScope = false ;
   this.AV5AdditionalScope = "" ;
   this.AV53GAMRAuthenticationTypeName = "" ;
   this.AV31GAMRServerURL = "" ;
   this.AV29GAMRPrivateEncryptKey = "" ;
   this.AV30GAMRRepositoryGUID = "" ;
   this.AV57AutovalidateExternalTokenAndRefresh = false ;
   this.AV47WSVersion = "" ;
   this.AV41WSPrivateEncryptKey = "" ;
   this.AV43WSServerName = "" ;
   this.AV44WSServerPort = 0 ;
   this.AV42WSServerBaseURL = "" ;
   this.AV45WSServerSecureProtocol = 0 ;
   this.AV46WSTimeout = 0 ;
   this.AV40WSPackage = "" ;
   this.AV39WSName = "" ;
   this.AV38WSExtension = "" ;
   this.AV24CusVersion = "" ;
   this.AV23CusPrivateEncryptKey = "" ;
   this.AV21CusFileName = "" ;
   this.AV22CusPackage = "" ;
   this.AV20CusClassName = "" ;
   this.AV37TypeId = "" ;
   this.Gx_mode = "" ;
   this.Events = {"e122q2_client": ["ENTER", true] ,"e132q2_client": ["'GENERATEKEY'", true] ,"e142q2_client": ["'GENERATEKEYCUSTOM'", true] ,"e162q1_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}],[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]];
   this.EvtParms["START"] = [[{av:'AV37TypeId',fld:'vTYPEID',pic:''},{av:'Gx_mode',fld:'vMODE',pic:'@!'},{av:'AV34Name',fld:'vNAME',pic:''},{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}],[{av:'AV36SmallImageName',fld:'vSMALLIMAGENAME',pic:''},{ctrl:'vFUNCTIONID'},{av:'AV28FunctionId',fld:'vFUNCTIONID',pic:''},{av:'AV34Name',fld:'vNAME',pic:''},{av:'AV25Dsc',fld:'vDSC',pic:''},{av:'AV14BigImageName',fld:'vBIGIMAGENAME',pic:''},{av:'AV32Impersonate',fld:'vIMPERSONATE',pic:''},{av:'AV16ClientId',fld:'vCLIENTID',pic:''},{av:'AV17ClientSecret',fld:'vCLIENTSECRET',pic:''},{av:'AV52VersionPath',fld:'vVERSIONPATH',pic:''},{av:'AV35SiteURL',fld:'vSITEURL',pic:''},{av:'AV5AdditionalScope',fld:'vADDITIONALSCOPE',pic:''},{av:'AV18ConsumerKey',fld:'vCONSUMERKEY',pic:''},{av:'AV19ConsumerSecret',fld:'vCONSUMERSECRET',pic:''},{av:'AV15CallbackURL',fld:'vCALLBACKURL',pic:''},{av:'AV53GAMRAuthenticationTypeName',fld:'vGAMRAUTHENTICATIONTYPENAME',pic:''},{av:'AV31GAMRServerURL',fld:'vGAMRSERVERURL',pic:''},{av:'AV29GAMRPrivateEncryptKey',fld:'vGAMRPRIVATEENCRYPTKEY',pic:''},{av:'AV30GAMRRepositoryGUID',fld:'vGAMRREPOSITORYGUID',pic:''},{ctrl:'vWSVERSION'},{av:'AV47WSVersion',fld:'vWSVERSION',pic:''},{av:'AV41WSPrivateEncryptKey',fld:'vWSPRIVATEENCRYPTKEY',pic:''},{av:'AV43WSServerName',fld:'vWSSERVERNAME',pic:''},{av:'AV44WSServerPort',fld:'vWSSERVERPORT',pic:'ZZZZ9'},{av:'AV42WSServerBaseURL',fld:'vWSSERVERBASEURL',pic:''},{ctrl:'vWSSERVERSECUREPROTOCOL'},{av:'AV45WSServerSecureProtocol',fld:'vWSSERVERSECUREPROTOCOL',pic:'9'},{av:'AV46WSTimeout',fld:'vWSTIMEOUT',pic:'ZZZZ9'},{av:'AV40WSPackage',fld:'vWSPACKAGE',pic:''},{av:'AV39WSName',fld:'vWSNAME',pic:''},{av:'AV38WSExtension',fld:'vWSEXTENSION',pic:''},{ctrl:'vCUSVERSION'},{av:'AV24CusVersion',fld:'vCUSVERSION',pic:''},{av:'AV23CusPrivateEncryptKey',fld:'vCUSPRIVATEENCRYPTKEY',pic:''},{av:'AV21CusFileName',fld:'vCUSFILENAME',pic:''},{av:'AV22CusPackage',fld:'vCUSPACKAGE',pic:''},{av:'AV20CusClassName',fld:'vCUSCLASSNAME',pic:''},{av:'gx.fn.getCtrlProperty("vNAME","Enabled")',ctrl:'vNAME',prop:'Enabled'},{ctrl:'BTNCONFIRM',prop:'Visible'},{ctrl:'BTNGENKEY',prop:'Visible'},{ctrl:'BTNGENKEYCUSTOM',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vISENABLE","Enabled")',ctrl:'vISENABLE',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vDSC","Enabled")',ctrl:'vDSC',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vSMALLIMAGENAME","Enabled")',ctrl:'vSMALLIMAGENAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vBIGIMAGENAME","Enabled")',ctrl:'vBIGIMAGENAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vIMPERSONATE","Enabled")',ctrl:'vIMPERSONATE',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vWSPRIVATEENCRYPTKEY","Enabled")',ctrl:'vWSPRIVATEENCRYPTKEY',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vWSSERVERNAME","Enabled")',ctrl:'vWSSERVERNAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vWSSERVERPORT","Enabled")',ctrl:'vWSSERVERPORT',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vWSSERVERBASEURL","Enabled")',ctrl:'vWSSERVERBASEURL',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vWSTIMEOUT","Enabled")',ctrl:'vWSTIMEOUT',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vWSPACKAGE","Enabled")',ctrl:'vWSPACKAGE',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vWSNAME","Enabled")',ctrl:'vWSNAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vWSEXTENSION","Enabled")',ctrl:'vWSEXTENSION',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCLIENTID","Enabled")',ctrl:'vCLIENTID',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCLIENTSECRET","Enabled")',ctrl:'vCLIENTSECRET',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vVERSIONPATH","Enabled")',ctrl:'vVERSIONPATH',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vSITEURL","Enabled")',ctrl:'vSITEURL',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCONSUMERKEY","Enabled")',ctrl:'vCONSUMERKEY',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCONSUMERSECRET","Enabled")',ctrl:'vCONSUMERSECRET',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCALLBACKURL","Enabled")',ctrl:'vCALLBACKURL',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCUSPRIVATEENCRYPTKEY","Enabled")',ctrl:'vCUSPRIVATEENCRYPTKEY',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCUSFILENAME","Enabled")',ctrl:'vCUSFILENAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCUSPACKAGE","Enabled")',ctrl:'vCUSPACKAGE',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vCUSCLASSNAME","Enabled")',ctrl:'vCUSCLASSNAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vADDUSERADDITIONALDATASCOPE","Enabled")',ctrl:'vADDUSERADDITIONALDATASCOPE',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vADDINITIALPROPERTIESSCOPE","Enabled")',ctrl:'vADDINITIALPROPERTIESSCOPE',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vADDITIONALSCOPE","Enabled")',ctrl:'vADDITIONALSCOPE',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vGAMRAUTHENTICATIONTYPENAME","Enabled")',ctrl:'vGAMRAUTHENTICATIONTYPENAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vGAMRSERVERURL","Enabled")',ctrl:'vGAMRSERVERURL',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vGAMRPRIVATEENCRYPTKEY","Enabled")',ctrl:'vGAMRPRIVATEENCRYPTKEY',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vGAMRREPOSITORYGUID","Enabled")',ctrl:'vGAMRREPOSITORYGUID',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vAUTOVALIDATEEXTERNALTOKENANDREFRESH","Enabled")',ctrl:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',prop:'Enabled'},{ctrl:'BTNCONFIRM',prop:'Caption'},{av:'gx.fn.getCtrlProperty("vSITEURL","Visible")',ctrl:'vSITEURL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLIMPERSONATE","Visible")',ctrl:'TBLIMPERSONATE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLCLIENTIDSECRET","Visible")',ctrl:'TBLCLIENTIDSECRET',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLCLIENTLOCALSERVER","Visible")',ctrl:'TBLCLIENTLOCALSERVER',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLSCOPES","Visible")',ctrl:'TBLSCOPES',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLAUTHTYPENAME","Visible")',ctrl:'TBLAUTHTYPENAME',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLCOMMONADDITIONAL","Visible")',ctrl:'TBLCOMMONADDITIONAL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLSERVERHOST","Visible")',ctrl:'TBLSERVERHOST',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLTWITTER","Visible")',ctrl:'TBLTWITTER',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLWEBSERVICE","Visible")',ctrl:'TBLWEBSERVICE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBLEXTERNAL","Visible")',ctrl:'TBLEXTERNAL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vVERSIONPATH","Visible")',ctrl:'vVERSIONPATH',prop:'Visible'},{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]];
   this.EvtParms["ENTER"] = [[{av:'Gx_mode',fld:'vMODE',pic:'@!'},{av:'AV20CusClassName',fld:'vCUSCLASSNAME',pic:''},{av:'AV22CusPackage',fld:'vCUSPACKAGE',pic:''},{av:'AV21CusFileName',fld:'vCUSFILENAME',pic:''},{av:'AV23CusPrivateEncryptKey',fld:'vCUSPRIVATEENCRYPTKEY',pic:''},{ctrl:'vCUSVERSION'},{av:'AV24CusVersion',fld:'vCUSVERSION',pic:''},{ctrl:'vWSSERVERSECUREPROTOCOL'},{av:'AV45WSServerSecureProtocol',fld:'vWSSERVERSECUREPROTOCOL',pic:'9'},{av:'AV42WSServerBaseURL',fld:'vWSSERVERBASEURL',pic:''},{av:'AV44WSServerPort',fld:'vWSSERVERPORT',pic:'ZZZZ9'},{av:'AV43WSServerName',fld:'vWSSERVERNAME',pic:''},{av:'AV38WSExtension',fld:'vWSEXTENSION',pic:''},{av:'AV39WSName',fld:'vWSNAME',pic:''},{av:'AV40WSPackage',fld:'vWSPACKAGE',pic:''},{av:'AV46WSTimeout',fld:'vWSTIMEOUT',pic:'ZZZZ9'},{av:'AV41WSPrivateEncryptKey',fld:'vWSPRIVATEENCRYPTKEY',pic:''},{ctrl:'vWSVERSION'},{av:'AV47WSVersion',fld:'vWSVERSION',pic:''},{av:'AV30GAMRRepositoryGUID',fld:'vGAMRREPOSITORYGUID',pic:''},{av:'AV29GAMRPrivateEncryptKey',fld:'vGAMRPRIVATEENCRYPTKEY',pic:''},{av:'AV31GAMRServerURL',fld:'vGAMRSERVERURL',pic:''},{av:'AV53GAMRAuthenticationTypeName',fld:'vGAMRAUTHENTICATIONTYPENAME',pic:''},{ctrl:'vFUNCTIONID'},{av:'AV28FunctionId',fld:'vFUNCTIONID',pic:''},{av:'AV15CallbackURL',fld:'vCALLBACKURL',pic:''},{av:'AV19ConsumerSecret',fld:'vCONSUMERSECRET',pic:''},{av:'AV18ConsumerKey',fld:'vCONSUMERKEY',pic:''},{av:'AV5AdditionalScope',fld:'vADDITIONALSCOPE',pic:''},{av:'AV35SiteURL',fld:'vSITEURL',pic:''},{av:'AV52VersionPath',fld:'vVERSIONPATH',pic:''},{av:'AV17ClientSecret',fld:'vCLIENTSECRET',pic:''},{av:'AV16ClientId',fld:'vCLIENTID',pic:''},{av:'AV32Impersonate',fld:'vIMPERSONATE',pic:''},{av:'AV14BigImageName',fld:'vBIGIMAGENAME',pic:''},{av:'AV36SmallImageName',fld:'vSMALLIMAGENAME',pic:''},{av:'AV25Dsc',fld:'vDSC',pic:''},{av:'AV34Name',fld:'vNAME',pic:''},{av:'AV37TypeId',fld:'vTYPEID',pic:''},{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}],[{ctrl:'vFUNCTIONID'},{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]];
   this.EvtParms["'GENERATEKEY'"] = [[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}],[{av:'AV41WSPrivateEncryptKey',fld:'vWSPRIVATEENCRYPTKEY',pic:''},{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]];
   this.EvtParms["'GENERATEKEYCUSTOM'"] = [[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}],[{av:'AV23CusPrivateEncryptKey',fld:'vCUSPRIVATEENCRYPTKEY',pic:''},{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]];
   this.EvtParms["VALIDV_FUNCTIONID"] = [[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}],[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]];
   this.EvtParms["VALIDV_WSVERSION"] = [[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}],[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]];
   this.EvtParms["VALIDV_CUSVERSION"] = [[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}],[{av:'AV33IsEnable',fld:'vISENABLE',pic:''},{av:'AV54AddUserAdditionalDataScope',fld:'vADDUSERADDITIONALDATASCOPE',pic:''},{av:'AV50AddInitialPropertiesScope',fld:'vADDINITIALPROPERTIESSCOPE',pic:''},{av:'AV57AutovalidateExternalTokenAndRefresh',fld:'vAUTOVALIDATEEXTERNALTOKENANDREFRESH',pic:''}]];
   this.EnterCtrl = ["BTNCONFIRM"];
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV37TypeId", "vTYPEID", 0, "char", 30, 0);
   this.Initialize( );
});
